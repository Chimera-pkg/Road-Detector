
export const columnsDataColumns = [
  {
    Header: "NOMOR",
    accessor: "nomor",
  },
  {
    Header: "TYPE",
    accessor: "type",
  },
  {
    Header: "CONFIDENCE",
    accessor: "confidence",
  },
  {
    Header: "BEFORE DETECTION",
    accessor: "before detection",
  },
  {
    Header: "AFTER DETECTION",
    accessor: "after detection",
  },
];

