export const columnsDataColumns = [
  {
    Header: "NOMOR",
    accessor: "nomor",
  },
  {
    Header: "FILE NAME",
    accessor: "file name",
  },
  {
    Header: "DATE",
    accessor: "date",
  },
  {
    Header: "DAMAGE",
    accessor: "damage amount",
  },
];

